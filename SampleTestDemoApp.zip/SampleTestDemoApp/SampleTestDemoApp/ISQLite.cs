﻿using System;
using SQLite;
namespace SampleTestDemoApp
{
    public interface ISQLite
    {
        SQLiteConnection GetConnection();
    }
}
