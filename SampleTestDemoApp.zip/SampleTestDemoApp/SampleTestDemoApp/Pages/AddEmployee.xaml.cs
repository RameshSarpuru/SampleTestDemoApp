﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace SampleTestDemoApp.Pages
{
    public partial class AddEmployee : ContentPage
    {
        public AddEmployee()
        {
            InitializeComponent();
        }

        public void OnSaveClicked(object sender, EventArgs args)
        {
            if (string.IsNullOrEmpty(txtEmpName.Text) && string.IsNullOrEmpty(txtDepartment.Text) && string.IsNullOrEmpty(txtDesign.Text) && string.IsNullOrEmpty(txtQualification.Text))
            {
                DisplayAlert("Alert", "All Fields are manditory", "OK");
                return;
            }
            var vEmployee = new Employee()
            {
                EmpName = txtEmpName.Text,
                Company = txtCompany.Text,
                Department = txtDepartment.Text,
                Designation = txtDesign.Text,
                Qualification = txtQualification.Text
            };
            App.DAUtil.SaveEmployee(vEmployee);
            Navigation.PushAsync(new ManageEmployee());
        }
    }
}
