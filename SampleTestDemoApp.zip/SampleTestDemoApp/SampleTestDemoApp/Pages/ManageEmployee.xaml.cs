﻿using System;
using Xamarin.Forms;



namespace SampleTestDemoApp.Pages
{
    public partial class ManageEmployee : ContentPage
    {
        public ManageEmployee()
        {
            InitializeComponent();
            var vList = App.DAUtil.GetAllEmployees();
            lstData.ItemsSource = vList;
        }

        public void editBtnClicked(object sender, EventArgs e)
        {
            Employee mSelEmployee = ((MenuItem)sender).CommandParameter as Employee;
            //  Employee aSelectedEmp = ((MenuItem)sender).CommandParameter as Employee;
            Navigation.PushAsync(new EditEmployee(mSelEmployee));

        }
        public async void deleteBtnClicked(object sender, EventArgs e)
        {
            Employee mSelEmployee = ((MenuItem)sender).CommandParameter as Employee;
            bool accepted = await DisplayAlert("Confirm", "Are you Sure ?", "Yes", "No");
            if (accepted)
            {
                App.DAUtil.DeleteEmployee(mSelEmployee);
            }
            var vList = App.DAUtil.GetAllEmployees();
            lstData.ItemsSource = vList;

            // await Navigation.PushAsync(new ManageEmployee());
        }

        void OnSelection(object sender, SelectedItemChangedEventArgs e)
        {
            if (e.SelectedItem == null)
            {
                return;
                //ItemSelected is called on deselection,   
                //which results in SelectedItem being set to null  
            }
            var vSelUser = (Employee)e.SelectedItem;
            Navigation.PushAsync(new ShowEmplyee(vSelUser));
        }
        public void OnNewClicked(object sender, EventArgs args)
        {
            Navigation.PushAsync(new AddEmployee());
        }
    }
}
